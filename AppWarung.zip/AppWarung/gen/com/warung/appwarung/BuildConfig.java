/** Automatically generated file. DO NOT MODIFY */
package com.warung.appwarung;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}