package com.warung.appwarung;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class MainActivity extends Activity implements OnClickListener, OnCheckedChangeListener {

	Button pindah1;
    EditText fieldnama,fieldemail;
    Button tomboltampil;
    RadioGroup groupjk;
    RadioButton radiolk, radiopr;
    CheckBox cekboxjava, cekboxsa, cekboxnet;
    TextView outputnama, outputemail, outputjk, outputahli;
    String jk, ahli;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        fieldemail = (EditText)findViewById(R.id.fieldemail);
        fieldnama = (EditText)findViewById(R.id.fieldnama);
        tomboltampil = (Button)findViewById(R.id.tomboltampil);
        groupjk = (RadioGroup)findViewById(R.id.groupjk);
        cekboxjava = (CheckBox)findViewById(R.id.cekboxjava);
        cekboxsa = (CheckBox)findViewById(R.id.cekboxsa);
        cekboxnet = (CheckBox)findViewById(R.id.cekboxnet);
        outputnama =(TextView)findViewById(R.id.outputnama);
        outputemail =(TextView)findViewById(R.id.outputemail);
        outputahli = (TextView)findViewById(R.id.outputahli);
        outputjk = (TextView)findViewById(R.id.outputjk);
        
        
        tomboltampil.setOnClickListener(this);
        groupjk.setOnCheckedChangeListener(this);        
        
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public void onClick(View klik) {
        // TODO Auto-generated method stub
    
        outputnama.setText("Nama Anda : "+fieldnama.getText());
        outputemail.setText("Bayar : "+fieldemail.getText());
        if (cekboxjava.isChecked() && cekboxnet.isChecked() && cekboxsa.isChecked()){
            outputahli.setText("Hidangan  : BATAGOR, PEMPEK, & CIMOL");
        }else if(cekboxjava.isChecked() && cekboxnet.isChecked()){
                outputahli.setText("Hidangan: BATAGOR & PEMPEK");
        }else if(cekboxjava.isChecked() && cekboxsa.isChecked()){
            outputahli.setText("Hidangan: BATAGOR & CIMOL");
        }else if(cekboxnet.isChecked() && cekboxsa.isChecked()){
            outputahli.setText("Hidangan: PEMPEK & CIMOL");
        }else if(cekboxjava.isChecked()){
            outputahli.setText("Hidangan: BATAGOR");
        }else if(cekboxnet.isChecked()){
            outputahli.setText("Hidangan: PEMPEK");            
        }else if(cekboxsa.isChecked()){
            outputahli.setText("Hidangan: CIMOL");
        }else{
            outputahli.setText("Hidangan: ");
            
        }
        outputjk.setText(jk);
        fieldnama.setText("");
        fieldemail.setText("");
        cekboxjava.setChecked(false);
        cekboxsa.setChecked(false);
        cekboxnet.setChecked(false);
        groupjk.clearCheck();
    }
    
    @Override
    public void onCheckedChanged(RadioGroup group, int check) {
        // TODO Auto-generated method stub
        if(check==R.id.radiolk){
            jk="Pakai Minum : YA ";
            
        }else if(check==R.id.radiopr){
                jk="Pakai Minum : TIDAK";
                
        }

        }
}